/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calctriangulo;

import java.util.Scanner;

/**
 *
 * @author 2016200848
 */
public class CalcTriangulo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner in = new Scanner(System.in);
        AreaTriangulo calculo = new AreaTriangulo();
        
        double alturaTriangulo, baseTriangulo, areaTriangulo;
        
        System.out.printf("Digite a altura: ");
        alturaTriangulo= in.nextFloat();
        
        System.out.printf("Digite a base: ");
        baseTriangulo=in.nextFloat();
        
        calculo.setAltura(alturaTriangulo);
        calculo.setBase(baseTriangulo);
        
        areaTriangulo= calculo.getArea();
        
        System.out.printf("A area do trinagulo e :%.2f",areaTriangulo);
  
        
        
        
    }
    
}
