package Model;


import java.io.Serializable; // serve para conseguir recuperar os dados pelo JavaBeans

/**
 * JavaBeans
 */
public class Funcionarios implements Serializable{
    
    private String nome;
    private int idade;
    private String nacionalidade;
    private String endereco;

    public Funcionarios() {
    }

    public Funcionarios(String nome, int idade, String nacionalidade, String endereco) {
        this.nome = nome;
        this.idade = idade;
        this.nacionalidade = nacionalidade;
        this.endereco = endereco;
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
    
    public void setIdade(int idade){
        this.idade = idade;
    }
    
    public void setNacionalidade(String nacionalidade){
        this.nacionalidade = nacionalidade;
    }
    
    public void setEndereco(String endereco){
        this.endereco = endereco;
    }
    
    public String getNome(){
        return this.nome;
    }
    
    public int getIdade(){
        return this.idade;
    }
    
    public String getNacionalidade(){
        return this.nacionalidade;
    }
    
    public String getEndereco(){
        return this.endereco;
    }
    
}
