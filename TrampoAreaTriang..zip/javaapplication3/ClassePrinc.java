/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3; 

/**
 *
 * @author 2017101024
 */
public class ClassePrinc {
    private double baseTriangulo;
    private double alturaTriangulo;

    
    public void setBaseTriangulo(double baseTriangulo) {
        this.baseTriangulo = baseTriangulo;
    }
   
    public void setAlturaTriangulo(double alturaTriangulo) {
        this.alturaTriangulo = alturaTriangulo;
    }
    public double getAreaTriangulo(){
        return (this.baseTriangulo*this.alturaTriangulo)/2;
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
